The files are the following:

.cmp - Copper Top Layer
.sol - Bottom Copper Layer
.stt - Cream Layer Top (for the stencil)
.stb - Cream Layer Bottom (for the stencil)
.drd - Drills and Holes
.stc - Solder Stopmask Top and Board Outline
.sts - Solder Stopmask Bottom and Board Outline

